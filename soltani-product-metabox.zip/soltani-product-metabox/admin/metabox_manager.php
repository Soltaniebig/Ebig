<?php
add_action( 'add_meta_boxes', 'dypm_add_metabox' );

function dypm_add_metabox(){
    add_meta_box(
    'dypm_product_meta',
    'اطلاعات محصولات',
    'dypm_metabox_callback',
    'post',
    'normal',
    'core',
    [
        'name' => [
            'test' => 'soltani',
            'test2' => 'soltani2',
        ],
    ]
    );
}

add_action( 'save_post', 'dypm_save_metabox', 10, 3);
function dypm_save_metabox ( $post_id, $post, $update){

    $price       = absint( $POST['dypm_price'] );
    $sale_price  = absint( $POST['dypm_sale_price'] );
    update_post_meta( $post_id, '_dypm_price', $price );
    update_post_meta( $post_id, '_dypm_sale_price', $Sale_price );

    //print_r( $post);exit;
}

function dypm_metabox_callback( $post, $args){

$price = get_post_meta( $post->ID, '_dypm_price', true );
$sale_price = get_post_meta( $post->ID, '_dypm_sale_price', true );

    include SOLTANI_PRODUCT_META_VIEW . 'metabox.php';
}