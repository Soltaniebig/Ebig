<?php
/**
 * Plugin Name: محصول ویژه -پیوان
 * Author: Soltani
 * Version: 1.0.0
 * Description: Task Pivan
 * Requires PHP: 6.4.2
 * Text Domain: پیوان
 * Copyright 2023
 */

 defined( 'ABSPATH' ) || exit;

 define( 'SOLTANI_PRODUCT_META_ADMIN_PATH' , plugin_dir_path(__FILE__) . 'admin/' );
 define( 'SOLTANI_PRODUCT_META_VIEW' , plugin_dir_path(__FILE__) . 'view/' );
 define( 'SOLTANI_PRODUCT_META_IMAGE' , plugin_dir_url(__FILE__) . 'assets/images/' );


 


 if( is_admin()){
    include ( SOLTANI_PRODUCT_META_ADMIN_PATH . 'metabox_manager.php');
 }






