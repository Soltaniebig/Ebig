<table class="form-table">
    <tbody>
        <tr>
            <th scope="row">
                <label for="dypm_price">
                   قیمت محصول : 
                </label>
            </th>
            <td>
                <input type="number" step="10000" id="dypm_price" name="dypm_price" value="<?php echo absint($price);?>">
            </td>
        </tr>
        <tr>
            <th scope="row">
                <label for="dypm_sale_price">
                    قیمت محصول ویژه: 
                </label>
            </th>
            <td>
                <input type="number" step="10000" id="dypm_sale_price" name="dypm_sale_price" value="0">
            </td>
        </tr>
    </tbody>
</table>